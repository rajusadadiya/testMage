<?php
$installer = $this;
$installer->startSetup();

$installer->getConnection()->addColumn($installer->getTable('bytescustomer/customer'), 'category_name',array(
        'type' => Varien_Db_Ddl_Table::TYPE_TEXT,
        'nullable' => true,
        'default' => null,
        'comment' => 'Category Name'
    ));

/*$installer->getConnection()
    ->addColumn($installer->getTable('inchoo_dbscript/ticket'),
    'created_at',
    array(
        'type' => Varien_Db_Ddl_Table::TYPE_TEXT,
        'nullable' => true,
        'default' => null,
        'comment' => 'Category Name'
    )
);*/
$installer->endSetup();

