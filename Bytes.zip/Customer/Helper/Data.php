<?php
  
class Bytes_Customer_Helper_Data extends Mage_Core_Helper_Abstract
{
	public function checkCustomer($customerId){

        $currentCategoryId = Mage::getSingleton('core/session')->getCustomerStateCategory();
        if(is_numeric($currentCategoryId)){
            $customerStateModule = Mage::getModel('bytescustomer/customer')->load($customerId);
            if($customerStateModule){
                if($customerStateModule->getCategoryId() != $currentCategoryId){
                    $category = Mage::getModel("catalog/category")->load($currentCategoryId);
                    $customerStateModule->setCategoryName($category->getName());
                    $customerStateModule->setCategoryId($currentCategoryId);
                    $customerStateModule->setCustomerId($customerId);
                    try{
                        $customerStateModule->save();
                    }
                    catch(Exception $e){
                        Mage::getSingleton('core/session')->addError(Mage::helper('bytescustomer')->__('Customer saving error %s',$e->getMessage()));
                    }
                }
            }
            else{
                $model = Mage::getModel('bytescustomer/customer');
                $category = Mage::getModel("catalog/category")->load($currentCategoryId);
                $data = ["category_id" => $currentCategoryId, "customer_id" => $customerId, "catagory_name" => $category->getName()];
                $model->setData($data);
                try{
                    $model->save();
                }
                catch(Exception $e){
                    Mage::getSingleton('core/session')->addError(Mage::helper('bytescustomer')->__('Customer saving error %s',$e->getMessage()));
                }
            }
        }
    }    
} 