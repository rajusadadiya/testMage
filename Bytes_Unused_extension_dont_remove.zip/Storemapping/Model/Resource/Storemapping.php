<?php 
class Bytes_Storemapping_Model_Resource_Storemapping extends Mage_Core_Model_Resource_Db_Abstract{
    protected function _construct()
    {
        $this->_init('storemapping/storemapping', 'mapping_id');
    }
}