<?php
  
class Bytes_Storemapping_Model_Mysql4_Storemapping extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {  
        $this->_init('storemapping/storemapping', 'mapping_id');
    }
}