<?php
  
class Bytes_Storemapping_Model_Mysql4_Storemapping_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        parent::__construct();
        $this->_init('storemapping/storemapping');
    }
} 