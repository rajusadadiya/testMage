<?php 

class Bytes_Storemapping_Block_Adminhtml_Customer extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_customer';
    $this->_blockGroup = 'storemapping';
    $this->_headerText = Mage::helper('storemapping')->__('Customer Manager');
    //$this->_addButtonLabel = Mage::helper('storemapping')->__('Add New Store Mapping');
    //$this->_removeButton("add");
    parent::__construct();
    $this->_removeButton('add');
  }
}