<?php 

class Bytes_Storemapping_Block_Adminhtml_Storemapping extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_storemapping';
    $this->_blockGroup = 'storemapping';
    $this->_headerText = Mage::helper('storemapping')->__('Store Mapping Manager');
    $this->_addButtonLabel = Mage::helper('storemapping')->__('Add New Store Mapping');
    
    $categoryCollection = Mage::helper("storemapping")->getMappingCategoryCollection();
    
    if($categoryCollection->count() > 0){
        $this->_addButtonLabel = Mage::helper('storemapping')->__('Edit Store Mapping');
//              
//        $this->_addButton('editall', array(
//            'label'     => Mage::helper('storemapping')->__('Edit All Mapping Store'),
//            'onclick'   => 'editAllMapping(this.id)',
//            'class'     => 'edit'
//        ), 0, 100, 'header', 'header');        
    }
    parent::__construct();
  }
}