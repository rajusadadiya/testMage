<?php

class Bytes_Storemapping_Block_Adminhtml_Storemapping_Edit
    extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                
        $this->_objectId = 'mapping_id';
        
        $this->_blockGroup = 'storemapping';
        $this->_controller = 'adminhtml_storemapping';

        $this->_updateButton('save', 'label', Mage::helper('storemapping')->__('Update Category Store Mapping'));
        
        $this->_mode = 'edit';
        
        $this->_removeButton('delete');
        $this->_removeButton('reset');

    }
  
    public function getHeaderText()
    {
        if(Mage::helper("storemapping")->getMappingCategoryCollection()->count() > 0) {
            return Mage::helper('storemapping')->__("Edit Category Store mapping");
        } else {
            return Mage::helper('storemapping')->__('Add Category Store Mapping');
        }
    }

    protected function _prepareLayout()
    {
        if ($this->_blockGroup && $this->_controller && $this->_mode) {
            $this->setChild('form', $this->getLayout()->createBlock($this->_blockGroup . '/' . $this->_controller . '_' . $this->_mode . '_form'));
        }
        return parent::_prepareLayout();
    }
} 