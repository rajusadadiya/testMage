<?php
 
class Bytes_Storemapping_Block_Adminhtml_Storemapping_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('storemapping_grid');
        $this->setDefaultSort('mapping_id');
        $this->setDefaultDir('ASC');
        $this->setSaveParametersInSession(true);
    }
 
    protected function _prepareCollection()
    {
        $collection = Mage::getModel('storemapping/storemapping')->getCollection();

        $categoryEntityId = Mage::helper('storemapping')->getCategoryEntityId();

        $categoryNameAttributeId = Mage::helper('storemapping')->getCategoryNameAttributeId();

        $collection->getSelect()
            ->columns('core_store.name AS store_name')
            ->columns('core_website.name AS website_name')
            ->columns('catalog_category_entity_varchar.value AS category_name')
            ->join('core_store','main_table.store_id = core_store.store_id')
            ->join('catalog_category_entity_varchar','main_table.category_id = catalog_category_entity_varchar.entity_id')
            ->join('core_website','main_table.website_id = core_website.website_id')
            ->where("catalog_category_entity_varchar.attribute_id = $categoryNameAttributeId AND  catalog_category_entity_varchar.entity_type_id = $categoryEntityId");

        $this->setCollection($collection);
        return parent::_prepareCollection();
    }
 
    protected function _prepareColumns()
    {
        $this->addColumn('mapping_id', array(
          'header'    => Mage::helper('storemapping')->__('ID'),
          'index'     => 'mapping_id',
        ));

        $this->addColumn('website_name', array(
          'header'    => Mage::helper('storemapping')->__('Website name'),
          'index'     => 'website_name',
          'filter_index' => 'core_store.name',  
        ));

        $this->addColumn('store_name', array(
          'header'    => Mage::helper('storemapping')->__('Store name'),
          'index'     => 'store_name',            
          'filter_index' => 'core_website.name',
        ));

        $this->addColumn('category_name', array(
          'header'    => Mage::helper('storemapping')->__('Category name'),
          'index'     => 'category_name',
          'filter_index' => 'catalog_category_entity_varchar.value',
        ));

        return parent::_prepareColumns();
    }
     
    public function getRowUrl($row)
    {
        // This is where our row data will link to
        //return $this->getUrl('*/*/edit', array('id' => $row->getId()));
        return false;
    }
}