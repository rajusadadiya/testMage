<?php

class Bytes_Storemapping_Block_Adminhtml_Storemapping_Edit_Form
    extends Mage_Adminhtml_Block_Widget_Form
{
    protected function _prepareForm()
    {
        // Instantiate a new form to display our brand for editing.
        $form = new Varien_Data_Form(array(
            'id' => 'edit_form',
            'action' => $this->getUrl(
                '*/*/save',
                array('id' => $this->getRequest()->getParam('id'))
            ),
            'method' => 'post',
        ));
        $form->setUseContainer(true);
        $this->setForm($form);

        $storemappingSingleton = Mage::getSingleton('storemapping/storemapping');

        $categoryCollection = Mage::helper("storemapping")->getMappingCategoryCollection();
        
        //echo $categoryCollection->count();

        if($categoryCollection->count() == 0){

            echo $this->__("Mapping Category not available, All category are added to mapping");
        }
        
        
        $count = 1;
        foreach ($this->getCategoryCollection() as $key => $category) {
            $key = (int) $key;            
            $fieldset = $form->addFieldset(
                'store_mapping_'.$key,
                array(
                    'legend' => $this->__('Category Store Mapping %s',$count)
                )
            );                
            
            $fieldset->addField('mapping_data['.$key.'][id]', 'hidden', array(
                'name'      => 'mapping_data['.$key.'][id]',
            ));
            
            $fieldset->addField('mapping_data['.$key.'][store_id]', 'select', array(
                'label' => $this->__('Store'),
                'name'      => 'mapping_data['.$key.'][store_id]',
                'values' => $this->getStoreValues(),
            ));
            
            $fieldset->addField('mapping_data['.$key.'][category_id]', 'select', array(
                'label' => $this->__('Category'),
                'name'      => 'mapping_data['.$key.'][category_id]',
                'values' => $this->getCategoryCollection(),
            ));
            $count++;
        }
        
        $arrayFinal = array();
        $storeCollection = Mage::getModel("storemapping/storemapping")->getCollection();
        $storeCollection->addFieldtoSelect("category_id");
        
        if($storeCollection->count() > 0 ){
            foreach($storeCollection as $key => $storemap){
                $varienObject = new Varien_Object();          
                $mapped = Mage::getModel("storemapping/storemapping")->load($storemap->getCategoryId(),"category_id");

                if(count($arrayFinal) == 0){
                    $arrayFinal = ["mapping_data[".$storemap->getCategoryId()."][id]"=>$mapped->getId(),"mapping_data[".$storemap->getCategoryId()."][store_id]"=>$mapped->getStoreId(),"mapping_data[".$storemap->getCategoryId()."][category_id]"=>$mapped->getCategoryId()];
                }
                else{
                    $id = "mapping_data[".$storemap->getCategoryId()."][id]";
                    $store_id = "mapping_data[".$storemap->getCategoryId()."][store_id]";
                    $category_id = "mapping_data[".$storemap->getCategoryId()."][category_id]";
                    $array_second = [$id=>$mapped->getId(),$store_id=>$mapped->getStoreId(),$category_id=>$mapped->getCategoryId()];
                    $arrayFinal = array_merge($array_second,$arrayFinal);   
                }
            }
            $varienObject->setData($arrayFinal);
            $form->setValues($varienObject->getData());
        }       
        
        // Define a new fieldset. We need only one for our simple entity.        

        return parent::_prepareForm();
    }

    public function getStoreData(){
        return Mage::helper("storemapping")->getStoreCollection();
    }

    public function getStoreValues(){

        $data_array[]= array();
        foreach ($this->getStoreData() as $key => $storeData) {
            $data_array[$storeData["store_id"]] = array('value'=>$storeData["store_id"],'label'=>$storeData["website_name"]." -> ".$storeData["store_name"]);   
        }
        return $data_array;
    }

    public function getCategoryCollection(){
        $collection = Mage::helper("storemapping")->getMappingCategoryCollection();
        $categoryArray = array();
        foreach ($collection as $key => $category) {
            $categoryArray[$category->getId()] = $category->getName();
        }
        return $categoryArray;
    }
}