<?php
 
class Bytes_Storemapping_Block_Adminhtml_Customer_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('customer_grid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('ASC');
        $this->setSaveParametersInSession(true);
    }
 
    protected function _prepareCollection()
    {
        $collection = Mage::getModel('storemapping/customer')->getCollection();

        $categoryEntityId = Mage::helper('storemapping')->getCategoryEntityId();
        $categoryNameAttributeId = Mage::helper('storemapping')->getCategoryNameAttributeId();
        $firstnameAttr = Mage::getModel('eav/entity_attribute')->loadByCode('1', 'firstname');
        $lastnameAttr = Mage::getModel('eav/entity_attribute')->loadByCode('1', 'lastname');

        $collection->getSelect()
            ->columns('catalog_category_entity_varchar.value AS category_name')
            ->columns(new Zend_Db_Expr("CONCAT(`first`.`value`, ' ',`last`.`value`) AS customer_name"))
            ->join('catalog_category_entity_varchar','main_table.category_id = catalog_category_entity_varchar.entity_id')
            ->join(array('customer' => 'customer_entity'), 'customer.entity_id = main_table.customer_id', array('email' => 'email'))
            ->join(array('first' => 'customer_entity_varchar'), 'first.entity_id = main_table.customer_id', array('firstname' => 'value'))
            ->join(array('last' => 'customer_entity_varchar'), 'last.entity_id = main_table.customer_id', array('lastname' => 'value'))
            ->where("catalog_category_entity_varchar.attribute_id = $categoryNameAttributeId AND  catalog_category_entity_varchar.entity_type_id = $categoryEntityId AND last.attribute_id = ".$lastnameAttr->getAttributeId()." AND first.attribute_id = ".$firstnameAttr->getAttributeId());
        
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }
 
    protected function _prepareColumns()
    {
        $this->addColumn('id', array(
          'header'    => Mage::helper('storemapping')->__('ID'),
          'index'     => 'id',
        ));

        $this->addColumn('customer_id', array(
          'header'    => Mage::helper('storemapping')->__('Customer ID'),
          'index'     => 'customer_id',
        ));

        $this->addColumn('customer_name', array(
          'header'    => Mage::helper('storemapping')->__('Customer name'),
          'index'     => 'customer_name',
//          'filter_index' => 'first.value',
          'filter'    => false,
          'sortable'  => false,
        ));

        $this->addColumn('email', array(
          'header'    => Mage::helper('storemapping')->__('Email'),
          'index'     => 'email',
//          'filter_index' => 'first.value',
          'filter'    => false,
          'sortable'  => false,
        ));


        $this->addColumn('category_name', array(
          'header'    => Mage::helper('storemapping')->__('Category name'),
          'index'     => 'category_name',
          'filter_index' => 'catalog_category_entity_varchar.value',
          'filter'    => false,
          'sortable'  => false,
        ));

        return parent::_prepareColumns();
    }
     
    public function getRowUrl($row)
    {
        // This is where our row data will link to
        //return $this->getUrl('*/*/edit', array('id' => $row->getId()));
        return false;
    }
}