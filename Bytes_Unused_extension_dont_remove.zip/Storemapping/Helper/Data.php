<?php
  
class Bytes_Storemapping_Helper_Data extends Mage_Core_Helper_Abstract
{
	
	const CATEGORY_ENTITY_CODE = 'catalog_category';

	public function getCategoryEntityId(){
        $eavSetupModel = Mage::getModel('eav/entity_type')->loadByCode(self::CATEGORY_ENTITY_CODE);
        return $eavSetupModel->getId();        
	}

	public function getCategoryNameAttributeId(){
		return Mage::getResourceModel('eav/entity_attribute')->getIdByCode(self::CATEGORY_ENTITY_CODE, 'name');
	}

	public function getStoreCollection(){
		$storeData = array();
        foreach(Mage::app()->getWebsites() as $website){
            foreach ($website->getGroups() as $group) {               
                $stores = $group->getStores();
                foreach ($stores as $store) {
                    $storeData[$store->getId()]["website_id"] = $website->getId();
                    $storeData[$store->getId()]["website_code"] = $website->getCode();
                    $storeData[$store->getId()]["website_name"] = $website->getName();
                    $storeData[$store->getId()]["group_id"] = $group->getId();
                    $storeData[$store->getId()]["group_name"] = $group->getName();
                    $storeData[$store->getId()]["group_category_id"] = $group->getRootCategoryId();
                    $storeData[$store->getId()]["store_id"] = $store->getId();
                    $storeData[$store->getId()]["store_code"] = $store->getCode();
                    $storeData[$store->getId()]["store_name"] = $store->getName();
                    
                }
            }
        }
        return $storeData;
	}

	public function getMappingCategoryCollection(){

        $categoryIdCollection = null;

        $mappedCategory = Mage::getModel("storemapping/storemapping")->getCollection()->addFieldToSelect("category_id");
        
        $categoryIds = array();
        foreach ($mappedCategory as $key => $storem) {
        	if(!in_array($storem["category_id"], $categoryIds)){
        		$categoryIds[] = $storem["category_id"]; 
        	}
        }

	$collection = Mage::getModel('catalog/category')->getCollection();
        $collection->addAttributeToSelect("*");
        $collection->addAttributeToFilter('is_state', 1);
        //$collection->addAttributeToFilter('entity_id', array('nin' => $categoryIds));
        return $collection;
	}
        
    public function getAllCategoryIsState(){
        $categoryCollection = Mage::getModel("catalog/category")->getCollection()->addAttributeToSelect("*")->addAttributeToFilter("is_state",1);
        return $categoryCollection;
    }

    public function getCategoryProductCollectionCount($categoryId){

        $_productCollection = null;
        $categoryId = (int) $categoryId;
        if(Mage::getSingleton("customer/session")->isLoggedIn()){
            $_productCollection = Mage::getModel('catalog/category')->load($categoryId)->getProductCollection();
            $pids = array();            
            $customer = Mage::getSingleton("customer/session")->getCustomer();
            $categoryState = Mage::getModel("storemapping/customer")->load($customer->getId(),"customer_id");                
            $loginCategoryId = $categoryState->getCategoryId();
            
            $categoryModel = Mage::getModel('catalog/category');
            
            if(is_numeric($categoryId) && $categoryModel->load($loginCategoryId)){
                $productCollection = $categoryModel->getProductCollection();
                foreach($productCollection as $product){
                    $pids[] = $product->getId();
                }
                $_productCollection->addAttributeToFilter('entity_id', array('in' => $pids));                     
            }
        }
        else{
            $_productCollection = Mage::getModel('catalog/category')->load($categoryId)->getProductCollection();
        }
        return $_productCollection->count();
    }

    public function checkCustomer($customerId){

        $currentCategoryId = Mage::getSingleton('core/session')->getCustomerStateCategory();
        if(is_numeric($currentCategoryId)){
            $customeCategoryStateModel = Mage::getModel('storemapping/customer')->load($customerId);
            if($customeCategoryStateModel){
                if($customeCategoryStateModel->getCategoryId() != $currentCategoryId){
                    $customeCategoryStateModel->setCategoryId($currentCategoryId);
                    $customeCategoryStateModel->setCustomerId($customerId);
                    try{
                        $customeCategoryStateModel->save();
                    }
                    catch(Exception $e){
                        Mage::getSingleton('core/session')->addError(Mage::helper('storemapping')->__('Customer saving error %s',$e->getMessage()));
                    }
                }
            }
            else{
                $model = Mage::getModel('storemapping/customer');

                $data = ["category_id" => $currentCategoryId, "customer_id" => $customerId];
                $model->setData($data);
                try{
                    $model->save();
                }
                catch(Exception $e){
                    Mage::getSingleton('core/session')->addError(Mage::helper('storemapping')->__('Customer saving error %s',$e->getMessage()));
                }
            }
        }
    }
} 