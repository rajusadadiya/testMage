<?php

$installer = $this;
$installer->startSetup();

$entityTypeId     = $installer->getEntityTypeId('catalog_category');
$attributeSetId   = $installer->getDefaultAttributeSetId($entityTypeId);
$attributeGroupId = $installer->getDefaultAttributeGroupId($entityTypeId, $attributeSetId);

$attribute  = array(
    'input'                     => 'select',
    'type'                      => 'int',
    'label'                     => 'is State',
    'source'                    => 'eav/entity_attribute_source_boolean',
    'global'                    => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
    'visible'                   => 1,
    'required'                  => 0,
    'visible_on_front'          => 1,
    'is_html_allowed_on_front'  => 0,
    'is_configurable'           => 0,
    'searchable'                => 0,
    'filterable'                => 0,
    'comparable'                => 0,
    'unique'                    => false,
    'user_defined'              => true,
    'default'                   => '0',
    'is_user_defined'           => true,
    'used_in_product_listing'   => true
);
$installer->addAttribute('catalog_category', 'is_state', $attribute);

$installer->addAttributeToGroup(
    $entityTypeId,
    $attributeSetId,
    $attributeGroupId,
    'is_state',
    '15'      
);

$installer->run("
  
-- DROP TABLE IF EXISTS {$this->getTable('bytes_store_category_mapping')};
CREATE TABLE {$this->getTable('bytes_store_category_mapping')} (
    `mapping_id` int(11) unsigned NOT NULL auto_increment,
    `store_id` smallint(5) NOT NULL default '0',
    `website_id` smallint(3) NOT NULL default '0',
    `category_id` int(11) NOT NULL default '0',
    PRIMARY KEY (`mapping_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
  
");

$installer->run("  
-- DROP TABLE IF EXISTS {$this->getTable('bytes_store_customer')};
CREATE TABLE {$this->getTable('bytes_store_customer')} (
    `id` int(11) unsigned NOT NULL auto_increment,
    `category_id` int(11) NOT NULL default '0',
    `customer_id` int(11) NOT NULL default '0',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;  
");

$installer->endSetup();

?>