<?php

class Bytes_Storemapping_Adminhtml_MappingController
    extends Mage_Adminhtml_Controller_Action
{
    public function indexAction()
    {
        // instantiate the grid container
        $brandBlock = $this->getLayout()
            ->createBlock('storemapping/adminhtml_storemapping');

        // Add the grid container as the only item on this page
        $this->loadLayout()
            ->_addContent($brandBlock)
            ->renderLayout();
    }

    /**
     * This action handles both viewing and editing existing brands.
     */
    public function editAction()
    {
        /*$posts = $this->getRequest()->getParams();
        print_r($posts);
        exit;*/

        $storeMapping = Mage::getModel('storemapping/storemapping');
        if ($mappingId = $this->getRequest()->getParam('id')) {
            $storeMapping->load($mappingId);
        }
        
        Mage::register('mapping_data', $storeMapping);

        $mappingEditBlock = $this->getLayout()->createBlock(
            'storemapping/adminhtml_storemapping_edit'
        );

        $this->loadLayout()
            ->_addContent($mappingEditBlock)
            ->renderLayout();
    }

    public function deleteAction()
    {
        $storeMapping = Mage::getModel('storemapping/storemapping');

        if ($mappingId = $this->getRequest()->getParam('id', false)) {
            $storeMapping->load($mappingId);
        }

        if ($storeMapping->getId()){

            $this->_getSession()->addError($this->__('This brand no longer exists.'));
            return $this->_redirect('*/*/');
        }

        try {
            $storeMapping->delete();

            $this->_getSession()->addSuccess(
                $this->__('The mapping has been deleted.')
            );
        } catch (Exception $e) {
            Mage::logException($e);
            $this->_getSession()->addError($e->getMessage());
        }

        return $this->_redirect('*/*/');
    }

    public function newAction()
    {
        $this->_forward('edit');
    }

    protected function _isAllowed()
    {
        $actionName = $this->getRequest()->getActionName();
        switch ($actionName) {
            case 'index':
            case 'edit':
            case 'delete':
                // intentionally no break
            default:
                $adminSession = Mage::getSingleton('admin/session');
                $isAllowed = $adminSession
                    ->isAllowed('admin/mapping');
                break;
        }

        return $isAllowed;
    }

    public function saveAction(){
        
        $posts = $this->getRequest()->getParams();
        
        if(isset($posts["mapping_data"]) && count($posts["mapping_data"]) > 0){            
            $stores = Mage::helper("storemapping")->getStoreCollection();
            foreach ($posts["mapping_data"] as $key => $value) {
                $issave = false;
                $_storeMappingModel = Mage::getModel("storemapping/storemapping");    
                if(isset($value["id"])){
                    $id = (int)$value["id"];
                    $_storeMappingModel->load($id);
                }
                $store = $stores[$value["store_id"]];
                $data = array( 
                    "website_id" => $store["website_id"],
                    "store_id" => $value["store_id"],
                    "category_id" => $value["category_id"],                        
                );
                //$_storeMappingModel = Mage::getModel("storemapping/storemapping")->load($value["category_id"],"category_id");
                if($_storeMappingModel->getId()){
                    if($_storeMappingModel->getStoreId() != $value["store_id"] || $_storeMappingModel->getCategoryId() != $value["category_id"]){
                        $issave = true;
                        $_storeMappingModel->setWebsiteId($data["website_id"]);
                        $_storeMappingModel->setStoreId($data["store_id"]);
                        $_storeMappingModel->setCategoryId($data["category_id"]);
                    }                    
                }
                else{                                      
                    $issave = true; 
                    $_storeMappingModel->setData($data);
                }
                
                try{ 
                    if($issave){
                        $_storeMappingModel->save();
                    }
                }
                catch(Exception $e){
                    $this->_getSession()->addError($this->__('Saving error %1',$e->getMessage()));
                    return $this->_redirect('admin/mapping/index');
                }
                     
            }
            $this->_getSession()->addSuccess($this->__('Store has been saved...'));
            return $this->_redirect('*/*/');
        }
    }
}