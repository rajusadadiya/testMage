<?php

class Bytes_Membership_CatalogController extends Mage_Core_Controller_Front_Action{
	
	public function cartaddAction()
	{

		$productId  = (int) $this->getRequest()->getParam('id');
		$callback  = (string) $this->getRequest()->getParam('callback');
		 
		$cart = Mage::getSingleton('checkout/cart');
		 
		// call the Magento catalog/product model
		$product = Mage::getModel('catalog/product')
		// set the current store ID
		->setStoreId(Mage::app()->getStore()->getId())
		// load the product object
		->load($productId);
		 
		$links = Mage::getModel('downloadable/product_type')->getLinks($product );
		 
		foreach ( $links as $link )
		if ( preg_match("/epub/i", $link->getTitle()) )
		$linkId = $link->getLinkId();
		 
		// Here is the trick to add the right link id
		 
		$input = array( 'qty' => 1, 'links' => array( $linkId ) );
		$request = new Varien_Object();
		$request->setData($input);
		 
		// start adding the product
		try {
		$cart->addProduct($product, $request);
		// save the cart
		$cart->save();
		 
		$result = null;
		} catch (Mage_Core_Exception $e) {
		$result = $e->getMessage();
		}
		 
		// very straightforward, set the cart as updated
		Mage::getSingleton('checkout/session')->setCartWasUpdated(true);
	}	
}
