<?php 

class Bytes_Membership_Helper_MDMembership extends MD_Membership_Helper_Data{

}